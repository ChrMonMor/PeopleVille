﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleVille.Lokalisation
{
    internal class Lokalisation
    {
        public int[] Postion;
        public string Navn;
        public int AntalHerNu;

        public Lokalisation(int[] postion, string navn, int antalHerNu)
        {
            Postion = postion;
            Navn = navn;
            AntalHerNu = antalHerNu;
        }
    }
}
