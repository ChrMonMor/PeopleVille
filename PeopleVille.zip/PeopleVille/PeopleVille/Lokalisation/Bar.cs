﻿using PeopleVille.Inbygger;
using PeopleVille.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleVille.Lokalisation
{
    internal class Bar : Lokalisation, IButik, IArbejdeplads
    {
        public Bar(int[] postion, string navn, int antalHerNu) : base(postion, navn, antalHerNu)
        {
        }

        float IButik.Kassen { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string[] IButik.Vare { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        int[] IButik.AntalPåLager { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        Indbygger[] IArbejdeplads.Arbejder { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        float IArbejdeplads.løn => throw new NotImplementedException();

        int IArbejdeplads.ArbejdesTimer { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        void IArbejdeplads.AnsætArbejder(Indbygger indbygger)
        {
            throw new NotImplementedException();
        }

        void IArbejdeplads.FyreArbejder(Indbygger inbygger)
        {
            throw new NotImplementedException();
        }
    }
}
