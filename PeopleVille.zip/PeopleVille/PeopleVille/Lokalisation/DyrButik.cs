﻿using PeopleVille.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleVille.Lokalisation
{
    internal class DyrButik : Lokalisation, IButik
    {
        public DyrButik(int[] postion, string navn, int antalHerNu) : base(postion, navn, antalHerNu)
        {
        }

        float IButik.Kassen { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string[] IButik.Vare { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        int[] IButik.AntalPåLager { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
