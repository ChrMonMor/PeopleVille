﻿using PeopleVille.Inbygger;
using PeopleVille.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleVille.Lokalisation
{
    internal class Vej : Lokalisation, IHjem
    {
        public Vej(int[] postion, string navn, int antalHerNu) : base(postion, navn, antalHerNu)
        {
        }

        Indbygger[] IHjem.HerBor { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        float IHjem.Pris { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        void IHjem.FlytInd(Indbygger indbygger)
        {
            throw new NotImplementedException();
        }

        void IHjem.FlytVæk(Indbygger indbygger)
        {
            throw new NotImplementedException();
        }
    }
}
