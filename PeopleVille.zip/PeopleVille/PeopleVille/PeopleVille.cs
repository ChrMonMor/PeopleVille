﻿using PeopleVille.Inbygger;
using PeopleVille.Lokalisation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleVille
{
    internal class PeopleVille
    {
        public List<Indbygger> indbyggers;
        public List<Lokalisation.Lokalisation> Lokalisationer;
        public GenstandHR genstandHR;
        public IndbyggerHR IndbyggerHR;
        public LokalisationHR LokalisationHR;

        public PeopleVille(List<Indbygger> indbyggers, List<Lokalisation.Lokalisation> lokalisationer, GenstandHR genstandHR, IndbyggerHR indbyggerHR, LokalisationHR lokalisationHR)
        {
            this.indbyggers = indbyggers;
            Lokalisationer = lokalisationer;
            this.genstandHR = genstandHR;
            IndbyggerHR = indbyggerHR;
            LokalisationHR = lokalisationHR;
        }
    }
}
