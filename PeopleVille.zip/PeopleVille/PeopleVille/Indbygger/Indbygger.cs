﻿namespace PeopleVille.Inbygger
{
    public class Indbygger
    {
    }
}