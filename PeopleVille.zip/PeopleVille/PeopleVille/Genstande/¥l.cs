﻿using PeopleVille.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleVille.Genstande
{
    internal class Øl : Genstande, IDrikkelse
    {
        public Øl(string name, string description, float pris) : base(name, description, pris)
        {
        }

        public override string Name { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public override string Description { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public override float Pris { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        float IDrikkelse.ALC => throw new NotImplementedException();
    }
}
