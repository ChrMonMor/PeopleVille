﻿using PeopleVille.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleVille.Genstande
{
    internal class Hammer : Genstande, IVærktøj
    {
        public Hammer(string name, string description, float pris) : base(name, description, pris)
        {
        }

        public override string Name { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public override string Description { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public override float Pris { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        string IVærktøj.KanBrugsHer => throw new NotImplementedException();

        float IVærktøj.Bonus { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
