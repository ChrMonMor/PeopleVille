﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleVille.Genstande.Madtyper
{
    internal class Kød : Mad
    {
        public Kød(string name, string description, float pris) : base(name, description, pris)
        {
        }

        public Kød(int kanHoldAntalDag, bool vegansk, string name, string description, float pris) : base(kanHoldAntalDag, vegansk, name, description, pris)
        {
        }
    }
}
