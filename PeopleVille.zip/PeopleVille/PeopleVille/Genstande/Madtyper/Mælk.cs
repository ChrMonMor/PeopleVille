﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleVille.Genstande.MadTyper
{
    internal class Mælk : Mad
    {
        public Mælk(string name, string description, float pris) : base(name, description, pris)
        {
        }

        public Mælk(int kanHoldAntalDag, bool vegansk, string name, string description, float pris) : base(kanHoldAntalDag, vegansk, name, description, pris)
        {
        }
    }
}
