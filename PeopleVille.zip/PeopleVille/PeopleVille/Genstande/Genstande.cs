﻿using PeopleVille.Inbygger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleVille.Genstande
{
    internal abstract class Genstande
    {
        public abstract string Name { get; set; }
        public abstract string Description { get; set; }
        public abstract float Pris { get; set; }

        protected Genstande(string name, string description, float pris)
        {
            Name = name;
            Description = description;
            Pris = pris;
        }
    }
}
