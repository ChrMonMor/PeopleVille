﻿using PeopleVille.Inbygger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleVille.Interfaces
{
    internal interface IHjem
    {
        Indbygger[] HerBor { get; set; }
        float Pris { get; set; }


        void FlytVæk(Indbygger indbygger);
        void FlytInd(Indbygger indbygger);

    }
}
